Create Mobile User:

This is a really simple AppleScript Studio application that allows you to create a Mobile User Account with a given local home directory.

- Getting Started -

* Open up the Xcode project.
* Edit "ldapDomain" and "pathToHomes" to reflect your LDAP domain and where you want the home directories to go to.
* Make sure you leave the trailing slash in for 'pathToHomes', otherwise you'll end up with home directories like: "/Volumes/Storage/Usersnigelkersten"


- Using it -

When you launch it, it will spend a few seconds collecting usernames so that you can auto-complete the combo box.
I've left a grep statement in there to illustrate how you can filter out unwanted usernames:
do shell script "dscl  " & ldapDomain & "  -list /Users | egrep -v '^(z|Z)[0-9]{7}' |egrep -v '^vpn_*' | grep -v admin  > /tmp/ldapusers.txt"

the section " egrep -v '^(z|Z)[0-9]{7}' " filters out our student ids, which are 'z' followed by 7 numbers. 
If you wanted to  pull that filter out, just change it to:

do shell script "dscl  " & ldapDomain & "  -list /Users |egrep -v '^vpn_*' | grep -v admin  > /tmp/ldapusers.txt"

and the same goes for the other filters, which remove admin accounts in my area and the vpn user accounts that get created.


No guarantees about this app. It's a rather quick and dirty hack, and you're welcome to do whatever you want with it. I'd appreciate seeing any improvements you make to it however.





Nigel Kersten
http://explanatorygap.net
