#import "AppController.h"
#import "AsyncSocket.h"

@implementation AppController


#pragma mark-
#pragma mark init/dealloc/awake

- (id)init 
{
    self = [super init];
    if ( self !=nil ) 
	{
		pool = [[NSAutoreleasePool alloc] init];
		aSocket = [[AsyncSocket alloc] initWithDelegate:self];
		serverNamespace = [[NSMutableString alloc] init];
		serverPathSeparator = [[NSMutableString alloc] init];	
		serverOtherUsersSeparator = [[NSMutableString alloc] init];		
		commandPrefix = 0;
		commandFinished = TRUE;
		loggedIn = FALSE;
		[self setMailboxes:nil];
		[self setAcls:nil];
		_usernamesDict = [[NSMutableDictionary alloc] init];
		[self setUsernames:[NSMutableArray arrayWithArray:[[_usernamesDict allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]]];
		
		NSDictionary *userDefaultsValuesDict;		
		userDefaultsValuesDict=[NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"DefaultSettings" ofType:@"plist"]];
		[[NSUserDefaults standardUserDefaults] registerDefaults:userDefaultsValuesDict];
		[[NSUserDefaultsController sharedUserDefaultsController] setInitialValues:userDefaultsValuesDict];
    }
    return self;
}


- (void)dealloc 
{
	[self setMailboxes:nil];
	[self setAcls:nil];
	[self setUsernames:nil];
	[self setQuotaRoot:nil];
	[self setQuotaUsed:nil];
	[self setQuotaQuota:nil];
	[self setMailboxComment:nil];
	[self setMailboxLastUpdated:nil];
	[self setMailboxPartition:nil];
	[self setMailboxSize:nil];
	[self setMailboxExpire:nil];
	[self setMailboxSquat:nil];
	[_usernamesDict release];
	[serverNamespace release];
	[serverPathSeparator release];
	[serverOtherUsersSeparator release];
	[aSocket release];
	[pool release];
    [super dealloc];
}


- (void)awakeFromNib 
{
	[cancelButton setEnabled:FALSE];
	[self disableMailboxElements];
	[loginActivityIndicator setHidden:TRUE];
	[connectButton setEnabled:FALSE];
	if ( [[rememberButton stringValue] isEqualToString:@"1"]) 
	{
		if ( [AGKeychain checkForExistenceOfKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]] )
		{ 
			[passwordTextField setStringValue:[AGKeychain getPasswordFromKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]]]; 
			[connectButton setEnabled:TRUE];
		}	
	}
	[mailboxesController setEditable:FALSE];
	[aclsController setEditable:FALSE];
	[aclsTable setEnabled:FALSE];
}


#pragma mark-
#pragma mark IBActions and Responses.

- (IBAction)cancel:(id)sender 
{
	if ([aSocket isConnected])
		[aSocket disconnect];
				
	[loginActivityIndicator stopAnimation:self];
	[loginActivityIndicator setHidden:TRUE];
	[loginStatusTextField setStringValue:@"Cancelled."];
	[self enableLoginElements];
}

- (IBAction)connect:(id)sender 
{
	[_usernamesDict removeAllObjects];
	[_usernamesDict setValue:@"anyone" forKey:@"anyone"];
		
	if ( [[rememberButton stringValue]isEqualToString:@"1"] )
		[self storePasswordInKeychainForUser:[usernameTextField stringValue] atHost:[addressTextField stringValue]];
	
	if ([[useSSLButton stringValue]isEqualToString:@"1"])
		[aSocket connectToHost:[addressTextField stringValue] onPort:993 error: nil];
	else
		[aSocket connectToHost:[addressTextField stringValue] onPort:143 error: nil];
			
	[cancelButton setEnabled:TRUE];
	[loginActivityIndicator setHidden:FALSE];
	[loginActivityIndicator startAnimation:self];
	[loginStatusTextField setStringValue:@"Connecting..."];
	[self disableLoginElements];
}


- (IBAction)editPreferences:(id)sender 
{

}

- (IBAction)refreshMailboxes:(id)sender 
{
	[self setMailboxes:[NSMutableArray array]];
	[self setUsernames:[NSMutableArray array]];
	if ( [[NSUserDefaults standardUserDefaults] boolForKey:@"collectUsernamesFromDirectoryServices"] )
		[self collectUsernamesFromDirectoryServices];
		
	[activityIndicator startAnimation:self];
	[activityTextField setStringValue:@"Refreshing Mailbox list..."];
	NSString *outputString = [[NSString alloc] initWithFormat:@"LIST%d LIST \"\" \"*\"\n", commandPrefix];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
}


- (IBAction)disconnectFromServer:(id)sender 
{
	[mailboxesWindow close];
	[loginWindow makeKeyAndOrderFront:self];
	[aSocket disconnect];
	[cancelButton setEnabled:FALSE];
	[self disableMailboxElements];
	[loginActivityIndicator setHidden:TRUE];
	[loginStatusTextField setStringValue:@""];
	
	if ( [[rememberButton stringValue] isEqualToString:@"1"])
	{
		if ( [AGKeychain checkForExistenceOfKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]] )
		{
			[passwordTextField setStringValue:[AGKeychain getPasswordFromKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]]]; 
			[connectButton setEnabled:TRUE];
		}
	}
}


- (IBAction)createMailbox:(id)sender 
{
	[confirmCreateMailboxButton setEnabled:FALSE];
	[newMailboxTextField setStringValue:@""];
	int status = [NSApp runModalForWindow:createMailboxPanel];
	
	if ( status == NSRunStoppedResponse ) 
	{
		NSString *outputString = [[NSString alloc] initWithFormat:@"CREATE%d CREATE \"%@\"\n", commandPrefix, [newMailboxTextField stringValue]];
		NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
		[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
		[outputString release];
	}
}


- (IBAction)deleteMailbox:(id)sender 
{
	NSMutableString *confirmString = [NSMutableString stringWithString:@"Please confirm you wish to delete mailbox(es):\n\n"];
	NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
	id mailboxObject;
	
	while ( mailboxObject = [objEnumerator nextObject])
		[confirmString appendFormat:@"%@\n", [mailboxObject valueForKey:@"name"]];
		
	[confirmString appendString:@"\n\nThis operation cannot be undone."];
	NSBeginAlertSheet(@"Delete Mailbox", @"OK", @"Cancel", nil, mailboxesWindow, self, NULL, @selector(endDeleteMailboxSheet:returnCode:contextInfo:), NULL, confirmString);
}


- (void)endDeleteMailboxSheet:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo 
{
	if (returnCode == NSAlertDefaultReturn) 
	{
		NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
		id mailboxObject;
		while ( mailboxObject = [objEnumerator nextObject]) 
		{
			NSString *outputString = [[NSString alloc] initWithFormat:@"DELETE%d DELETE \"%@\"\n", commandPrefix, [mailboxObject objectForKey:@"name"]];
			NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
			[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
			[outputString release];
		}
	}
}


- (IBAction)renameMailbox:(id)sender 
{
	[confirmRenameMailboxButton setEnabled:FALSE];
	[newNameMailboxTextField setStringValue:[[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	int status = [NSApp runModalForWindow:renameMailboxPanel];
	if ( status == NSRunStoppedResponse ) 
	{
		NSString *outputString = [[NSString alloc] initWithFormat:@"RENAME%d RENAME \"%@\" \"%@\"\n", commandPrefix, [[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"], [newNameMailboxTextField stringValue]];
		NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
		[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
		[outputString release];
	}
}


- (IBAction)reconstructMailbox:(id)sender 
{
	NSMutableString *confirmString = [NSMutableString stringWithString:@"Please confirm you wish to reconstruct mailbox(es):\n\n"];
	NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
	id mailboxObject;
	
	while ( mailboxObject = [objEnumerator nextObject]) 
		[confirmString appendFormat:@"%@\n", [mailboxObject valueForKey:@"name"]];
		
	[confirmString appendString:@"\n\nThis operation cannot be undone."];
	NSBeginAlertSheet(@"Reconstruct Mailbox", @"OK", @"Cancel", nil, mailboxesWindow, self, NULL, @selector(endReconstructMailboxSheet:returnCode:contextInfo:), NULL, confirmString);
}


- (void)endReconstructMailboxSheet:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo 
{
	if (returnCode == NSAlertDefaultReturn) 
	{
		NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
		id mailboxObject;
		while (mailboxObject = [objEnumerator nextObject]) 
		{
			NSString *outputString = [[NSString alloc] initWithFormat:@"RECONSTRUCT%d RECONSTRUCT \"%@\"\n", commandPrefix, [mailboxObject objectForKey:@"name"]];
			NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
			[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
			[outputString release];
		}
	}
}


- (IBAction)createAcl:(id)sender 
{
	[newAclUsernameTextField setStringValue:[usernameTextField stringValue]];
	[confirmCreateACLButton setEnabled:FALSE];
	int status = [NSApp runModalForWindow:createACLPanel];
	if ( status == NSRunStoppedResponse ) 
	{
		NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
		id mailboxObject;
		while ( mailboxObject = [objEnumerator nextObject]) 
		{
			NSMutableString *aclWriteString = [NSMutableString stringWithFormat:@"SETACL%d SETACL \"%@\" \"%@\"", commandPrefix, [mailboxObject objectForKey:@"name"], [newAclUsernameTextField stringValue]];	
			[aclWriteString appendString:@" "];
			if ( [[aclCheckboxL stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"l"]; }
			if ( [[aclCheckboxR stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"r"]; }
			if ( [[aclCheckboxS stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"s"]; }
			if ( [[aclCheckboxW stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"w"]; }
			if ( [[aclCheckboxI stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"i"]; }
			if ( [[aclCheckboxP stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"p"]; }
			if ( [[aclCheckboxC stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"c"]; }
			if ( [[aclCheckboxD stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"d"]; }
			if ( [[aclCheckboxA stringValue] isEqualToString:@"1"] ) { [aclWriteString appendString:@"a"]; }
			[aclWriteString appendString:[NSString stringWithFormat:@"\n"]];
			NSData *writeData = [NSData dataWithBytes:[aclWriteString cString] length:[aclWriteString cStringLength]];
			[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
		}
	}
}


- (IBAction)deleteAcl:(id)sender 
{
	NSBeginAlertSheet(@"Delete ACL", @"OK", @"Cancel", nil, mailboxesWindow, self, NULL, @selector(endDeleteAclSheet:returnCode:contextInfo:), NULL, @"Please confirm you wish to delete the ACL on mailbox \"%@\"for user \"%@\".\n\nThis operation cannot be undone.", [[[mailboxesController selectedObjects]objectAtIndex:0]objectForKey:@"name"], [[[aclsController selectedObjects]objectAtIndex:0]objectForKey:@"User"]);
}


- (void)endDeleteAclSheet:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo 
{
	if (returnCode == NSAlertDefaultReturn) 
	{
		NSString *outputString = [[NSString alloc] initWithFormat:@"DELETEACL%d DELETEACL \"%@\" %@\n", commandPrefix, [[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"], [[[aclsController selectedObjects]objectAtIndex:0]objectForKey:@"User"]];
		NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
		[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
		[outputString release];
	}
}


- (IBAction)checkAclCheckboxes:(id)sender 
{
	BOOL enableCreateAclButton = FALSE;
	if ([[newAclUsernameTextField stringValue]isEqualToString:@""]) 
		enableCreateAclButton = FALSE;
	else if ( [[aclCheckboxL stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxR stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxS stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxW stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxI stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxP stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxC stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxD stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	else if ( [[aclCheckboxA stringValue] isEqualToString:@"1"] )
		enableCreateAclButton = TRUE;
	
	if ( enableCreateAclButton )
		[confirmCreateACLButton setEnabled:TRUE];
	else
		[confirmCreateACLButton setEnabled:FALSE];
}

- (IBAction)checkSquatCheckbox:(id)sender
{
	if ( [[mailboxesController selectedObjects] count] > 1 )
		[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
	else
		if ( ((![[updateMailboxSquatButton stringValue] isEqualToString:@"1"]) && [[self mailboxSquat] isEqualToString:@"true"]) || ([[updateMailboxSquatButton stringValue] isEqualToString:@"1"] && (![[self mailboxSquat] isEqualToString:@"true"])))
			[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
		else
			[confirmUpdateMailboxMetadataButton setEnabled:FALSE];
}


- (IBAction)editMailboxMetadata:(id)sender
{
  // NSLog(@"%s", _cmd);
	
  	if ( [[mailboxesController selectedObjects] count] > 1 )
	{
		[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
		[statusUpdateMetadataTextField setStringValue:@"You have more than one mailbox selected. The settings in this screen will apply to all selected mailboxes."];
	}
	else
	{
		[confirmUpdateMailboxMetadataButton setEnabled:FALSE];
		[statusUpdateMetadataTextField setStringValue:@""];
	}
		
	if ( [self mailboxComment] != nil )
		[updateMailboxCommentTextField setStringValue:[self mailboxComment]];
	else
		[updateMailboxCommentTextField setStringValue:@""];
		
	if ( [self mailboxExpire] != nil )			
		[updateMailboxExpireTextField setStringValue:[self mailboxExpire]];
	else
		[updateMailboxExpireTextField setStringValue:@""];
		
	if ( [[self mailboxSquat] isEqualToString:@"true"] )
		[updateMailboxSquatButton setStringValue:@"1"];
	else
		[updateMailboxSquatButton setStringValue:@"0"];
		
	int status = [NSApp runModalForWindow:editMetadataPanel];

	if ( status == NSRunStoppedResponse ) 
	{
		if ( [[mailboxesController selectedObjects] count] > 1 )    // multiple mailboxes. just apply values.
		{
			NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
			id mailboxObject;
			while ( mailboxObject = [objEnumerator nextObject])
			{ 		
				NSString *commentOutputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/comment\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"], [updateMailboxCommentTextField stringValue]];
				NSData *commentWriteData = [NSData dataWithBytes:[commentOutputString cString] length:[commentOutputString cStringLength]];
				[aSocket writeData:commentWriteData withTimeout:10 tag:commandPrefix];
				[commentOutputString release];
				
				if ([[updateMailboxExpireTextField stringValue] isEqualToString:@""])
				{
					NSString *expireOutputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/expire\" (\"value.shared\" NIL)\n", commandPrefix, [mailboxObject objectForKey:@"name"]];
					NSData *expireWriteData = [NSData dataWithBytes:[expireOutputString cString] length:[expireOutputString cStringLength]];
					[aSocket writeData:expireWriteData withTimeout:10 tag:commandPrefix];
					[expireOutputString release];
				}
				else 
				{
					NSString *expireOutputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/expire\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"] ,[updateMailboxExpireTextField stringValue]];
					NSData *expireWriteData = [NSData dataWithBytes:[expireOutputString cString] length:[expireOutputString cStringLength]];
					[aSocket writeData:expireWriteData withTimeout:10 tag:commandPrefix];
					[expireOutputString release];
				}
				
				NSString *squatValue = ( ([[updateMailboxSquatButton stringValue] isEqualToString:@"1"]) ? [NSString stringWithString:@"true"] : [NSString stringWithString:@"false"]);
				NSString *squatOutputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/squat\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"], squatValue];
				NSData *squatWriteData = [NSData dataWithBytes:[squatOutputString cString] length:[squatOutputString cStringLength]];
				[aSocket writeData:squatWriteData withTimeout:10 tag:commandPrefix];
				[squatOutputString release];
			}
			[self retrieveMailboxAnnotations];
			[activityTextField setStringValue:@"Metadata updated."];
		}
		else	// single mailbox selected. check values. need to stop this using enumerators now, will fix later.
		{
		if (! [[updateMailboxCommentTextField stringValue] isEqualToString:[self mailboxComment]])
			{
				NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
				id mailboxObject;
				while ( mailboxObject = [objEnumerator nextObject])
				{ 		
					NSString *outputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/comment\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"], [updateMailboxCommentTextField stringValue]];
					NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
					[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
					[outputString release];
				}
				[self retrieveMailboxAnnotations];
				[activityTextField setStringValue:@"Metadata updated."];
			}
			if (! [[updateMailboxExpireTextField stringValue] isEqualToString:[self mailboxExpire]])
			{
				if ([[updateMailboxExpireTextField stringValue] isEqualToString:@""])
				{
					NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
					id mailboxObject;
					while ( mailboxObject = [objEnumerator nextObject])
					{			
						NSString *outputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/expire\" (\"value.shared\" NIL)\n", commandPrefix, [mailboxObject objectForKey:@"name"]];
						NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
						[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
						[outputString release];
					}
				}
				else
				{
					NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
					id mailboxObject;
					while ( mailboxObject = [objEnumerator nextObject])
					{			
						NSString *outputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/expire\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"] ,[updateMailboxExpireTextField stringValue]];
						NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
						[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
						[outputString release];
					}
				}
				[self retrieveMailboxAnnotations];
				[activityTextField setStringValue:@"Metadata updated."];
			}
			// this is long and unwieldy... but it's to make sure that the value is actually different...
			if ( ((![[updateMailboxSquatButton stringValue] isEqualToString:@"1"]) && [[self mailboxSquat] isEqualToString:@"true"]) || ([[updateMailboxSquatButton stringValue] isEqualToString:@"1"] && (![[self mailboxSquat] isEqualToString:@"true"])))
			{
				NSEnumerator *objEnumerator = [[mailboxesController selectedObjects] objectEnumerator];
				id mailboxObject;
				while ( mailboxObject = [objEnumerator nextObject])
				{						
					NSString *squatValue = ( ([[updateMailboxSquatButton stringValue] isEqualToString:@"1"]) ? [NSString stringWithString:@"true"] : [NSString stringWithString:@"false"]);
					NSString *outputString = [[NSString alloc] initWithFormat:@"SETANNOCATION%d SETANNOTATION \"%@\" \"/vendor/cmu/cyrus-imapd/squat\" (\"value.shared\" \"%@\")\n", commandPrefix, [mailboxObject objectForKey:@"name"], squatValue];
					NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
					[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
					[outputString release];
				}
				[self retrieveMailboxAnnotations];
				[activityTextField setStringValue:@"Metadata updated."];
			}		
		}
	}
}


- (IBAction)setQuota:(id)sender 
{
}


- (IBAction)confirmAlertPanel:(id)sender 
{
	[NSApp stopModal];
	[[sender window] close];
}


- (IBAction)abortAlertPanel:(id)sender 
{
	[NSApp abortModal];
	[[sender window] close];
}


- (IBAction)enableAllAclsForNewAcl:(id)sender 
{
	if ( [[aclCheckboxL stringValue] isEqualToString:@"0"] ) 
	{
		[aclCheckboxL setStringValue:@"1"];
		[aclCheckboxR setStringValue:@"1"];
		[aclCheckboxS setStringValue:@"1"];	
		[aclCheckboxW setStringValue:@"1"];
		[aclCheckboxI setStringValue:@"1"];
		[aclCheckboxP setStringValue:@"1"];	
		[aclCheckboxC setStringValue:@"1"];
		[aclCheckboxD setStringValue:@"1"];
		[aclCheckboxA setStringValue:@"1"];
		[confirmCreateACLButton setEnabled:TRUE];	
	} 
	else 
	{
		[aclCheckboxL setStringValue:@"0"];
		[aclCheckboxR setStringValue:@"0"];
		[aclCheckboxS setStringValue:@"0"];	
		[aclCheckboxW setStringValue:@"0"];
		[aclCheckboxI setStringValue:@"0"];
		[aclCheckboxP setStringValue:@"0"];	
		[aclCheckboxC setStringValue:@"0"];
		[aclCheckboxD setStringValue:@"0"];
		[aclCheckboxA setStringValue:@"0"];
		[confirmCreateACLButton setEnabled:FALSE];
	}
}

- (void)connectionDisconnected:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo 
{
	[mailboxesWindow close];
	[loginWindow makeKeyAndOrderFront:self];
	[loginStatusTextField setStringValue:@""];
	[self enableLoginElements];
}

#pragma mark-
#pragma mark Internals

- (void)storePasswordInKeychainForUser:(NSString*)kUsername atHost:(NSString*)kHostname 
{
	if ( [AGKeychain checkForExistenceOfKeychainItem:@"SirAdmin" withItemKind:kHostname forUsername:kUsername] )
		[AGKeychain modifyKeychainItem:@"SirAdmin" withItemKind:kHostname forUsername:kUsername withNewPassword:[passwordTextField stringValue]];
	else
		[AGKeychain addKeychainItem:@"SirAdmin" withItemKind:kHostname forUsername:[usernameTextField stringValue] withPassword:[passwordTextField stringValue]];
}


- (void)disableLoginElements 
{
	[connectButton setEnabled:FALSE];
	[addressTextField setEnabled:FALSE];
	[usernameTextField setEnabled:FALSE];
	[passwordTextField setEnabled:FALSE];
	[rememberButton setEnabled:FALSE];
	[useSSLButton setEnabled:FALSE];
}


- (void)enableLoginElements 
{
	[connectButton setEnabled:TRUE];
	[addressTextField setEnabled:TRUE];
	[usernameTextField setEnabled:TRUE];
	[passwordTextField setEnabled:TRUE];
	[rememberButton setEnabled:TRUE];
	[useSSLButton setEnabled:TRUE];
}


- (void)disableMailboxElements 
{
	[deleteMailboxButton setEnabled:FALSE];
	[renameMailboxButton setEnabled:FALSE];
	[reconstructMailboxButton setEnabled:FALSE];
	[deleteAclButton setEnabled:FALSE];
	[createAclButton setEnabled:FALSE];
	[quotaRootTextField setEnabled:FALSE];
	[quotaUsedTextField setEnabled:FALSE];
	[quotaQuotaTextField setEnabled:FALSE];
//	[setQuotaButton setEnabled:FALSE];
}


- (void)enableMailboxElements 
{
	[createMailboxButton setEnabled:TRUE];
	[deleteMailboxButton setEnabled:TRUE];
	[renameMailboxButton setEnabled:TRUE];
	[reconstructMailboxButton setEnabled:TRUE];
	[deleteAclButton setEnabled:TRUE];
	[createAclButton setEnabled:TRUE];
	[quotaRootTextField setEnabled:TRUE];
	[quotaUsedTextField setEnabled:TRUE];
	[quotaQuotaTextField setEnabled:TRUE];
//	[setQuotaButton setEnabled:TRUE];
}


- (void)readFromServer 
{
	NSData *newline = [@"\n" dataUsingEncoding:NSASCIIStringEncoding];
	[aSocket readDataToData:newline withTimeout:-1 tag:0];
}


- (void)collectUsernamesFromDirectoryServices 
{
    long dirStatus;
    tDirReference gDirRef;
    tDirNodeReference nodeRef;
    tDataListPtr nodeName;
    tDataList recNames;
    tDataList recTypes;
    tDataList attrTypes;
    tRecordEntry *pRecEntry;
    unsigned long recCount, i;
    tAttributeListRef attrListRef;
    tAttributeValueListRef uidValueRef;
    tAttributeValueEntry *pUidValueEntry;
    tAttributeEntry *pUidAttrEntry;
    tDataBufferPtr dataBuffer;
    unsigned long bufferCount;
    tContextData context = NULL;
    
	int minUid = [[[NSUserDefaults standardUserDefaults] valueForKey:@"minimumUidFromDirectoryServices"] intValue];
	int maxUid = [[[NSUserDefaults standardUserDefaults] valueForKey:@"maximumUidFromDirectoryServices"] intValue];
	
    // Start a directory service session
    dsOpenDirService( &gDirRef );
    dataBuffer = dsDataBufferAllocate( gDirRef, 32 * 1024 );

    dirStatus = dsFindDirNodes(gDirRef, dataBuffer, NULL, eDSAuthenticationSearchNodeName, &bufferCount, &context );
	if (dirStatus == eDSNoErr) 
	{
		nodeName = dsDataListAllocate( gDirRef );
		dirStatus = dsGetDirNodeName( gDirRef, dataBuffer, 1, &nodeName );
		if (dirStatus == eDSNoErr) 
		{	
			dirStatus = dsOpenDirNode( gDirRef, nodeName, &nodeRef);
			if (dirStatus == eDSNoErr) 
			{
				dsBuildListFromStringsAlloc ( gDirRef, &recNames, kDSRecordsAll, NULL );
				dsBuildListFromStringsAlloc ( gDirRef, &recTypes, kDSStdRecordTypeUsers, NULL );
				dsBuildListFromStringsAlloc ( gDirRef, &attrTypes, kDS1AttrUniqueID, kDSNAttrRecordName, NULL );
				
				do {
					dsGetRecordList( nodeRef, dataBuffer, &recNames, eDSExact, &recTypes, &attrTypes, 0, &recCount, &context );
					for ( i = 1; i <= recCount; i++ ) 
					{
						BOOL addThisUser = TRUE;
						dsGetRecordEntry( nodeRef, dataBuffer, i, &attrListRef, &pRecEntry );
						dsGetAttributeEntry( nodeRef, dataBuffer, attrListRef, 1, &uidValueRef, &pUidAttrEntry );
						dsGetAttributeValue( nodeRef, dataBuffer, 1, uidValueRef, &pUidValueEntry);
						int uidNumber = [[NSString stringWithUTF8String:pUidValueEntry->fAttributeValueData.fBufferData] intValue];	
						
						if ( ((minUid > 0) && (uidNumber < minUid)) || ((maxUid > 0) && (uidNumber > maxUid)) )
							addThisUser = FALSE;
						
						if ( addThisUser ) 
						{
							tAttributeValueListRef	usernameValueRef;
							tAttributeValueEntry	*pUsernameValueEntry;
							tAttributeEntry *pUsernameAttrEntry;
							dsGetAttributeEntry( nodeRef, dataBuffer, attrListRef, 2, &usernameValueRef, &pUsernameAttrEntry );
							dsGetAttributeValue( nodeRef, dataBuffer, 1, usernameValueRef, &pUsernameValueEntry);
							[_usernamesDict setValue:[NSString stringWithUTF8String:pUsernameValueEntry->fAttributeValueData.fBufferData] forKey:[NSString stringWithUTF8String:pUsernameValueEntry->fAttributeValueData.fBufferData]];
							dsDeallocAttributeValueEntry( gDirRef, pUsernameValueEntry );
							pUsernameValueEntry = NULL;
							dsDeallocAttributeEntry(gDirRef, pUsernameAttrEntry);
							pUsernameAttrEntry = NULL;
							dsCloseAttributeValueList( usernameValueRef );
						}
						
						dsDeallocAttributeValueEntry( gDirRef, pUidValueEntry );
						pUidValueEntry = NULL;
						dsDeallocAttributeEntry(gDirRef, pUidAttrEntry);
						pUidAttrEntry = NULL;
						dsCloseAttributeValueList( uidValueRef );
						dsCloseAttributeList( attrListRef );
						attrListRef = nil;
						dsDeallocRecordEntry( gDirRef, pRecEntry );
						pRecEntry = NULL;
					}
				} while (context != NULL); // Loop until all of the data has been obtained.
				
				dsDataListDeallocate(gDirRef, &recNames);
				dsDataListDeallocate(gDirRef, &recTypes);
				dsDataListDeallocate(gDirRef, &attrTypes);
				dsDataListDeallocate(gDirRef,nodeName);
				dsCloseDirNode( nodeRef );
			}
		}
	}
	
    dsCloseDirService( gDirRef );
	[self setUsernames:[NSMutableArray arrayWithArray:[[_usernamesDict allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]]];
}


- (void)retrieveAccessControls 
{
	[self setAcls:[NSMutableArray array]];
	NSString *outputString = [[NSString alloc] initWithFormat:@"GETACL%d GETACL \"%@\"\n", commandPrefix, [[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
}


- (void)retrieveQuotaInfo 
{
	[self setQuotaRoot:nil];
	[self setQuotaUsed:nil];
	[self setQuotaQuota:nil];
	NSString *outputString = [[NSString alloc] initWithFormat:@"GETQUOTAROOT%d GETQUOTAROOT \"%@\"\n", commandPrefix, [[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
}

- (void)retrieveMailboxAnnotations
{
  // NSLog(@"%s", _cmd);
	[self setMailboxComment:@""];
	[self setMailboxLastUpdated:@""];
	[self setMailboxPartition:@""];
	[self setMailboxSize:@""];
	[self setMailboxExpire:@""];
	[self setMailboxSquat:@""];
	NSString *outputString = [[NSString alloc] initWithFormat:@"GETANNOTATIONS%d GETANNOTATION \"%@\" \"*\" \"value.shared\"\n", commandPrefix, [[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
}


#pragma mark-
#pragma mark Socket Delegate Methods.

-(BOOL) onSocketWillConnect:(AsyncSocket *)sock 
{
	if (CFDictionaryContainsKey(SCDynamicStoreCopyProxies(NULL),kCFStreamPropertySOCKSProxyHost))
		CFReadStreamSetProperty([aSocket getCFReadStream],kCFStreamPropertySOCKSProxy,SCDynamicStoreCopyProxies(NULL));
	
	if ([[useSSLButton stringValue] isEqualToString:@"1"]) 
	{
		CFMutableDictionaryRef sslDict = CFDictionaryCreateMutable(kCFAllocatorDefault, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
		if (sslDict) 
		{
			CFDictionaryAddValue(sslDict, kCFStreamSSLLevel, kCFStreamSocketSecurityLevelNegotiatedSSL);
			if ( [[NSUserDefaults standardUserDefaults] boolForKey:@"allowExpiredCertificates"] )
				CFDictionaryAddValue(sslDict, kCFStreamSSLAllowsExpiredCertificates, kCFBooleanTrue);
			if ( [[NSUserDefaults standardUserDefaults] boolForKey:@"allowExpiredRootCertificates"] )
				CFDictionaryAddValue(sslDict, kCFStreamSSLAllowsExpiredRoots, kCFBooleanTrue);
			if (! [[NSUserDefaults standardUserDefaults] boolForKey:@"validateCertificateChain"] )
				CFDictionaryAddValue(sslDict, kCFStreamSSLValidatesCertificateChain, kCFBooleanFalse);
			if ( [[NSUserDefaults standardUserDefaults] boolForKey:@"ignoreHostnameWhenMatchingCertificate"] )
				CFDictionaryAddValue(sslDict, kCFStreamSSLPeerName, kCFNull);
			CFReadStreamSetProperty([aSocket getCFReadStream], kCFStreamPropertySSLSettings, sslDict);
			CFRelease(sslDict);
			return TRUE;
		} 
		else 
		{
			return FALSE;
		}
	}
	return TRUE;
}


-(void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port 
{
	NSString *outputString = [[NSString alloc] initWithFormat:@"%d CAPABILITY\n", commandPrefix];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
	[self readFromServer];
}


-(void)onSocket:(AsyncSocket *)sock willDisconnectWithError:(NSError *)err 
{
//    NSLog(@"%s", _cmd);
	[loginActivityIndicator stopAnimation:self];
	[loginActivityIndicator setHidden:TRUE];

	NSString *errorString = ( (err != NULL)	? [NSString stringWithString:[err localizedDescription]] : [NSString stringWithString:@"Unknown Error."] );		
	
	if ([NSApp keyWindow] == loginWindow)
	{
		[loginStatusTextField setStringValue:errorString];
		[self enableLoginElements];
	} 
	else
	{
		NSBeginAlertSheet(@"You have been disconnected from the IMAP server.", @"OK", nil, nil, mailboxesWindow, self, NULL, @selector(connectionDisconnected:returnCode:contextInfo:), NULL, errorString );
	}
	[aSocket disconnect];
}


-(void)onSocketDidDisconnect:(AsyncSocket *)sock 
{
  // NSLog(@"%s", _cmd);
}


-(void)onSocket:(AsyncSocket *)sock didReadData:(NSData*)data withTag:(long)tag 
{
  // NSLog(@"%s", _cmd);
	NSString *incomingString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	
//	if ( ! [[incomingString substringToIndex:6] isEqualToString:@"* LIST"] )
//		NSLog(@"read %@", incomingString);

/* CAPABILITY */	
	if ( [[incomingString substringToIndex:12] isEqualToString:@"* CAPABILITY"] ) 
		[self didReadCapabilities:incomingString];
/* GOT CRAM-MD5 CHALLENGE */
	else if ( [[incomingString substringToIndex:2] isEqualToString:@"+ "] )
		[self doWriteCramMd5Response:incomingString];
/* NAMESPACE REQUEST */
	else if ( [[incomingString substringToIndex:12] isEqualToString:@"* NAMESPACE "] )
		[self didReadNamespaceRequest:incomingString];
/* STILL GETTING DATA */
	else if ( [[incomingString substringToIndex:1] isEqualToString:@"*"] && loggedIn)
	{   
		commandFinished = FALSE;
		if ( [[incomingString substringWithRange: NSMakeRange(2,4)] isEqualToString:@"LIST"] ) 
			[self didReadMailboxList:incomingString]; 
		else if ( [[incomingString substringWithRange: NSMakeRange(2,3)] isEqualToString:@"ACL"] ) 
			[self didReadAclList:incomingString];
		else if ( [[incomingString substringWithRange: NSMakeRange(2,9)] isEqualToString:@"QUOTAROOT"] ) 
		{
			[self didReadQuotaRoot:incomingString];
		} 
		else if ( [[incomingString substringWithRange: NSMakeRange(2,6)] isEqualToString:@"QUOTA "] ) 
		{
			[self didReadQuotaQuota:incomingString];
		}
		else if ( [[incomingString substringWithRange: NSMakeRange(2,11)] isEqualToString:@"ANNOTATION "] )
		{
			[self didReadAnnotation:incomingString];
		}
				
	}
/* LOGIN OR AUTHENTICATE */	 
	else if ( ([[incomingString substringToIndex:5] isEqualToString:@"LOGIN"]) || ([[incomingString substringToIndex:12] isEqualToString:@"AUTHENTICATE"]) ) 
		[self didReadLogin:incomingString]; 
	else if ( [[incomingString substringToIndex:4] isEqualToString:@"LIST"] ) 
	{
		commandPrefix += 1;
		[mailboxesController rearrangeObjects];
		[activityIndicator stopAnimation:self];
		[activityTextField setStringValue:@"Mailbox list retrieved."];
		[self setUsernames:[NSMutableArray arrayWithArray:[[_usernamesDict allValues]sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]]];
	} 
/* GETACL */			
	else if ( [[incomingString substringToIndex:6] isEqualToString:@"GETACL"] ) 
	{
		if ([incomingString rangeOfString:@"NO Mailbox does not exist"].length != 0 ) 
		{
			commandPrefix += 1;
				NSBeginAlertSheet(@"Mailbox does not exist.", @"OK", nil,
				nil, mailboxesWindow, self, NULL,
				@selector(refreshMailboxes:),
				NULL,
				@"This mailbox does not exist. The mailbox list will now refresh.");
		} 
		else 
		{
			commandPrefix += 1;
			[aclsController rearrangeObjects];
		}	
	}
/* GETQUOTAROOT */		 
	else if ( [[incomingString substringToIndex:12] isEqualToString:@"GETQUOTAROOT"] ) 
	{
		commandPrefix += 1;
	}
/* GET ANNOTATIONS*/	
	else if ( [[incomingString substringToIndex:14] isEqualToString:@"GETANNOTATIONS"] ) 
	{
		commandPrefix += 1;
	}
/* DELETEACL */		 
	else if ( [[incomingString substringToIndex:9] isEqualToString:@"DELETEACL"] ) 
	{
		commandPrefix += 1;
		[self retrieveAccessControls];
	} 
/* CREATE MAILBOX */			
	else if ( [[incomingString substringToIndex:6] isEqualToString:@"CREATE"]) 
	{
		commandPrefix += 1;
		[self refreshMailboxes:self];
	}
/* DELETE MAILBOX */		 
	else if ( [[incomingString substringToIndex:6] isEqualToString:@"DELETE"]) 
	{
		if ([incomingString rangeOfString:@"NO Permission denied"].length != 0 ) 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"Permission denied."];
		} 
		else if ([incomingString rangeOfString:@"NO Mailbox does not exist"].length != 0 ) 
		{
			commandPrefix += 1;
				NSBeginAlertSheet(@"Mailbox does not exist.", @"OK", nil,
				nil, mailboxesWindow, self, NULL,
				@selector(refreshMailboxes:),
				NULL,
				@"This mailbox does not exist. The mailbox list will now refresh.");
		} 
		else 
		{
			commandPrefix += 1;
			[self refreshMailboxes:self];
		}
	} 
/* RENAME MAILBOX */			
	else if ( [[incomingString substringToIndex:6] isEqualToString:@"RENAME"]) 
	{
		if ([incomingString rangeOfString:@"NO Permission denied"].length != 0 ) 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"Permission denied."];
		} 
		else if ([incomingString rangeOfString:@"NO Mailbox does not exist"].length != 0 ) 
		{
			commandPrefix += 1;
				NSBeginAlertSheet(@"Mailbox does not exist.", @"OK", nil,
				nil, mailboxesWindow, self, NULL,
				@selector(refreshMailboxes:),
				NULL,
				@"This mailbox does not exist. The mailbox list will now refresh.");
		} else {
			commandPrefix += 1;
			[self refreshMailboxes:self];
		}
	} 
/* RECONSTRUCT MAILBOX */			
	else if ( [[incomingString substringToIndex:11] isEqualToString:@"RECONSTRUCT"]) 
	{
		if ([incomingString rangeOfString:@"NO Permission denied"].length != 0 ) 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"Permission denied."];
		} 
		else if ([incomingString rangeOfString:@"NO Mailbox does not exist"].length != 0 ) 
		{
			commandPrefix += 1;
			NSBeginAlertSheet(@"Mailbox does not exist.", @"OK", nil, nil, mailboxesWindow, self, NULL, @selector(refreshMailboxes:), NULL, @"This mailbox does not exist. The mailbox list will now refresh.");
		} 
		else 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"Mailbox reconstructed."];
		}
	} 
/* SETACL */			
	else if ( [[incomingString substringToIndex:6] isEqualToString:@"SETACL"]) 
	{
		if ([incomingString rangeOfString:@"NO Permission denied"].length != 0 ) 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"Permission denied."];
		} 
		else if ([incomingString rangeOfString:@"NO Mailbox does not exist"].length != 0 ) 
		{
			commandPrefix += 1;
			NSBeginAlertSheet(@"Mailbox does not exist.", @"OK", nil, nil, mailboxesWindow, self, NULL, @selector(refreshMailboxes:), NULL, @"This mailbox does not exist. The mailbox list will now refresh.");
		} 
		else 
		{
			commandPrefix += 1;
			[activityTextField setStringValue:@"ACL created."];
			if ( [[mailboxesController selectedObjects] count] == 1) 
				[self retrieveAccessControls];
		}
	}
	
	if ( [incomingString rangeOfString:@"OK"].length != 0 )  
		commandFinished = TRUE;

	[incomingString autorelease];
	[self readFromServer];
}

-(void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag {
  // NSLog(@"%s", _cmd);
}


#pragma mark-
#pragma mark Socket Writing 

-(void)doWriteCramMd5Login
{
	NSString *outputString = [[NSString alloc] initWithFormat:@"AUTHENTICATE%d AUTHENTICATE CRAM-MD5\n", commandPrefix];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:555];
	[outputString release];
	[self readFromServer];
}

-(void)doWriteCramMd5Response:(NSString*)incomingString
{
	// NSLog(@"%s", _cmd);
	NSString *outputString = [[NSString alloc] initWithFormat:@"%@\n",[NKCramMD5 imapCramMd5ResultForUsername:[usernameTextField stringValue] password:[passwordTextField stringValue] challenge:[incomingString substringFromIndex:2]]];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
	[self readFromServer];	
}


-(void)doWritePlainTextLogin
{
  // NSLog(@"%s", _cmd);
	NSString *outputString = [[NSString alloc] initWithFormat:@"LOGIN%d LOGIN %@ \"%@\"\n", commandPrefix, [usernameTextField stringValue], [passwordTextField stringValue]];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
	[self readFromServer];
}

-(void)doWriteNamespaceRequest
{
	NSString *outputString = [[NSString alloc] initWithFormat:@"NAMESPACE%d NAMESPACE\n", commandPrefix];
	NSData *writeData = [NSData dataWithBytes:[outputString cString] length:[outputString cStringLength]];
	[aSocket writeData:writeData withTimeout:10 tag:commandPrefix];
	[outputString release];
	[self readFromServer];
}


#pragma mark-
#pragma mark Socket Reading 

-(void)didReadCapabilities:(NSString*)incomingString
{
  // NSLog(@"%s", _cmd);
	if ([incomingString rangeOfString:@"AUTH=CRAM-MD5"].length > 0 ) 
		[self doWriteCramMd5Login];
	else 
		[self doWritePlainTextLogin];
}


-(void)didReadMailboxList:(NSString*)incomingString
{
  // NSLog(@"%s", _cmd);
	NSMutableString *mailboxName = [NSMutableString stringWithString:[[incomingString componentsSeparatedByString:[NSString stringWithFormat:@"\"%@\" \"", serverPathSeparator]] lastObject]];
	[mailboxName deleteCharactersInRange: NSMakeRange([mailboxName cStringLength] - 3, 3)];
	[_mailboxesArray addObject:[NSMutableDictionary dictionaryWithObject:mailboxName forKey:@"name"]];
	if ( ! [[NSUserDefaults standardUserDefaults] boolForKey:@"collectUsernamesFromDirectoryServices"] ) 
	{	
//		if ([mailboxName rangeOfString:@"user/"].length != 0 ) 
//		{
//			NSString *thisUsername = [NSString stringWithString:[[[[mailboxName componentsSeparatedByString:@"user/"] lastObject] componentsSeparatedByString:@"/"] objectAtIndex:0]];
//			[_usernamesDict setValue:thisUsername forKey:thisUsername];
//		}
//		else if ([mailboxName rangeOfString:@"Other Users/"].length != 0 ) 
//		{
//			NSString *thisUsername = [NSString stringWithString:[[[[mailboxName componentsSeparatedByString:@"Other Users/"] lastObject] componentsSeparatedByString:@"/"] objectAtIndex:0]];
//			[_usernamesDict setValue:thisUsername forKey:thisUsername];
//		}

/*	This is the new method trying to cope with multiple namespace formats... */

		if ([mailboxName rangeOfString:serverOtherUsersSeparator].length != 0)
		{
			NSString *thisUsername = [NSString stringWithString:[[[[mailboxName componentsSeparatedByString:serverOtherUsersSeparator] lastObject] componentsSeparatedByString:serverPathSeparator] objectAtIndex:0]];
			[_usernamesDict setValue:thisUsername forKey:thisUsername];
		}
		
	}
}


-(void)didReadAclList:(NSString*)incomingString
{
	NSString *aSeparatorString;
	NSString *currentMailbox = [NSString stringWithString:[[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	if ( [currentMailbox rangeOfString:@" "].length != 0 ) 
		aSeparatorString = [NSString stringWithFormat:@"%@\" ", currentMailbox];
	else
		aSeparatorString = [NSString stringWithFormat:@"%@ ", currentMailbox];

	NSMutableString *acl = [NSMutableString stringWithString:[[incomingString componentsSeparatedByString:aSeparatorString] lastObject]];
	[acl replaceOccurrencesOfString:@"\r\n" withString:@"" options:NSBackwardsSearch range: NSMakeRange(0, [acl length])];
	NSArray *theseAcls = [acl componentsSeparatedByString:@" "];
	int i;
	if (! [[theseAcls objectAtIndex:0] isEqualToString:@"*"] )  // visual glitch
	{
		for (i = 0; i < [theseAcls count] - 1; i += 2) 
		{
			NSMutableDictionary* aclDict = [NSMutableDictionary dictionaryWithObject:[theseAcls objectAtIndex:i] forKey:@"User"];
			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"l"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"l"];
			else
				[aclDict setObject:@"" forKey:@"l"];
				
			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"r"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"r"];
			else
				[aclDict setObject:@"" forKey:@"r"];
				
			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"s"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"s"];
			else
				[aclDict setObject:@"" forKey:@"s"];
				
			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"w"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"w"];
			else
				[aclDict setObject:@"" forKey:@"w"];
				
			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"i"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"i"];
			else
				[aclDict setObject:@"" forKey:@"i"];

			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"p"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"p"];
			else
				[aclDict setObject:@"" forKey:@"p"];

			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"c"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"c"];
			else
				[aclDict setObject:@"" forKey:@"c"];

			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"d"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"d"];
			else
				[aclDict setObject:@"" forKey:@"d"];

			if ( [[theseAcls objectAtIndex:(i+1)] rangeOfString:@"a"].length != 0 )
				[aclDict setObject:[NSString stringWithUTF8String:"\xe2\x88\x9a"] forKey:@"a"];
			else
				[aclDict setObject:@"" forKey:@"a"];
				
			[_aclsArray addObject:aclDict];
		}
	}
}


-(void)didReadQuotaRoot:(NSString*)incomingString
{
	NSString *currentMailbox = [NSString stringWithString:[[[mailboxesController selectedObjects] objectAtIndex:0] objectForKey:@"name"]];
	NSString *qSeparatorString;
	if ( [currentMailbox rangeOfString:@" "].length != 0 )
		qSeparatorString = [NSString stringWithFormat:@"%@\" ", currentMailbox];
	else
		qSeparatorString = [NSString stringWithFormat:@"%@ ", currentMailbox];
		
	if ( [[[[incomingString componentsSeparatedByString:qSeparatorString] lastObject] substringToIndex:1] isEqualToString:@"*"]) 
		[self setQuotaRoot:@""];
	else
		[self setQuotaRoot:[[incomingString componentsSeparatedByString:qSeparatorString] lastObject]];
	
	[self setQuotaUsed:@""];
	[self setQuotaQuota:@""];
}

-(void)didReadQuotaQuota:(NSString*)incomingString
{
	[self setQuotaUsed:[[[[incomingString componentsSeparatedByString:@"STORAGE "] lastObject] componentsSeparatedByString:@" "] objectAtIndex:0]];
	[self setQuotaQuota:[[[[[[incomingString componentsSeparatedByString:@"STORAGE "] lastObject] componentsSeparatedByString:@" "] lastObject]componentsSeparatedByString:@")"]objectAtIndex:0]];			
}


-(void)didReadAnnotation:(NSString*)incomingString
{			
	if ( [incomingString rangeOfString:@"/vendor/cmu/cyrus-imapd/lastupdate"].length != 0 )
		[self setMailboxLastUpdated:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
	else if ( [incomingString rangeOfString:@"/vendor/cmu/cyrus-imapd/partition"].length != 0 )
		[self setMailboxPartition:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
	else if ( [incomingString rangeOfString:@"/vendor/cmu/cyrus-imapd/size"].length != 0 )
		[self setMailboxSize:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
	else if ( [incomingString rangeOfString:@"\"/comment\""].length != 0 )
		[self setMailboxComment:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
	else if ( [incomingString rangeOfString:@"/vendor/cmu/cyrus-imapd/expire"].length != 0 )
		[self setMailboxExpire:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
	else if ( [incomingString rangeOfString:@"/vendor/cmu/cyrus-imapd/squat"].length != 0 )
		[self setMailboxSquat:[[[[incomingString componentsSeparatedByString:@"value.shared\" \""] lastObject] componentsSeparatedByString:@"\")"] objectAtIndex:0]];
		
}

-(void)didReadLogin:(NSString*)incomingString
{
	if ( [incomingString rangeOfString:@"OK"].length != 0 ) 
	{
		[loginActivityIndicator stopAnimation:self];
		[loginStatusTextField setStringValue:@"Logged in..."];
		commandPrefix += 1;
		[self enableLoginElements];
		[loginWindow orderOut:self];
		
		//[self refreshMailboxes:self];
		[self doWriteNamespaceRequest];
		[mailboxesWindow makeKeyAndOrderFront:self];
		[mailboxesTable selectAll:self];
		loggedIn = TRUE;
	} 
	else 
	{
		if ([[incomingString substringToIndex:12] isEqualToString:@"AUTHENTICATE"])
			[self doWritePlainTextLogin];			// try to login with plain if CRAM-MD5 has failed.
		else
		{
			[loginActivityIndicator stopAnimation:self];
			[loginStatusTextField setStringValue:@"Login Failed."];
			[self enableLoginElements];
			[aSocket disconnect];
		}
	}
}

-(void)didReadNamespaceRequest:(NSString*)incomingString
{
	// foreign.
	// * NAMESPACE (("INBOX." ".")) (("user." ".")) (("" "."))  
	// nigelkersten
	// * NAMESPACE (("" "/")) (("Other Users/" "/")) (("Shared Folders/" "/"))
	// cyrusadmin
	// * NAMESPACE (("INBOX/" "/")) (("user/" "/")) (("" "/"))

	serverNamespace = [[incomingString componentsSeparatedByString:@"NAMESPACE "] lastObject];
	[serverPathSeparator setString:[[serverNamespace componentsSeparatedByString:@")) (("] objectAtIndex:1]];
	[serverPathSeparator setString:[[serverPathSeparator componentsSeparatedByString:@" "] lastObject]];
	[serverPathSeparator setString:[serverPathSeparator substringWithRange:NSMakeRange(1,1)]];
	
	[serverOtherUsersSeparator setString:[[serverNamespace componentsSeparatedByString:@")) (("] objectAtIndex:1]];
	[serverOtherUsersSeparator setString:[[serverOtherUsersSeparator componentsSeparatedByString:@"\""] objectAtIndex:1]];
	
	NSLog(@"server namespace: %@", serverNamespace);
	NSLog(@"path separator: %@", serverPathSeparator);
	NSLog(@"user separator: %@", serverOtherUsersSeparator);

	[self refreshMailboxes:self];
}



#pragma mark-
#pragma mark AppKit delegates


- (void)controlTextDidChange:(NSNotification *)aNotification 
{
	if ( ([aNotification object] == addressTextField) || ([aNotification object] == usernameTextField) || ([aNotification object] == passwordTextField) ) 
	{
		if ([[addressTextField stringValue] isEqualToString:@""] || [[usernameTextField stringValue] isEqualToString:@""] || [[passwordTextField stringValue] isEqualToString:@""] ) 
			[connectButton setEnabled:FALSE];
		else
			[connectButton setEnabled:TRUE];
	} 
	
	if ( ([aNotification object] == updateMailboxCommentTextField) || ([aNotification object] == updateMailboxExpireTextField) )
	{
		if ( [[mailboxesController selectedObjects] count] > 1 )
			[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
		else 
			if ( (![[updateMailboxCommentTextField stringValue] isEqualToString:[self mailboxComment]]) || (![[updateMailboxExpireTextField stringValue] isEqualToString:[self mailboxExpire]]) )
				[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
			else
				[confirmUpdateMailboxMetadataButton setEnabled:FALSE];
	}	

	if ( ([aNotification object] == addressTextField) || ([aNotification object] == usernameTextField) ) 
	{
		if ( [AGKeychain checkForExistenceOfKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]] ) 
		{
			NSString *keychainPassword = [NSString stringWithString:[AGKeychain getPasswordFromKeychainItem:@"SirAdmin" withItemKind:[addressTextField stringValue] forUsername:[usernameTextField stringValue]]]; 
			if (keychainPassword != NULL) 
			{
				[passwordTextField setStringValue: keychainPassword];
				[connectButton setEnabled:TRUE];
			} 
			else 
			{
				[passwordTextField setStringValue:@""];
			}
		} 
		else 
		{
			[passwordTextField setStringValue:@""];
		}
	} 
	else if ([aNotification object] == newMailboxTextField) 
	{
		if ( ! [[[aNotification object] stringValue] isEqualToString:@""]) 
		{
			if (! [[[[aNotification object] stringValue] substringFromIndex:([[[aNotification object] stringValue] length] -1)] isEqualToString:@"/"]) 
			{
				if ( [_mailboxesArray containsObject:[NSDictionary dictionaryWithObject:[[aNotification object] stringValue] forKey:@"name"]]) 
				{
					[confirmCreateMailboxButton setEnabled: FALSE];
					[newMailboxStatusField setStringValue:@"Mailbox already exists."];
				} 
				else 
				{
					[newMailboxStatusField setStringValue:@""];
					[confirmCreateMailboxButton setEnabled: TRUE];
				}
			}
		} 
		else 
		{
			[confirmCreateMailboxButton setEnabled: FALSE];
		}
	} 
	else if ([aNotification object] == newNameMailboxTextField) 
	{
		if ( ! [[[aNotification object] stringValue] isEqualToString:@""]) 
		{
			if (! [[[[aNotification object] stringValue] substringFromIndex:([[[aNotification object] stringValue] length] -1)] isEqualToString:@"/"]) 
			{
				if ( [_mailboxesArray containsObject:[NSDictionary dictionaryWithObject:[[aNotification object] stringValue] forKey:@"name"]]) 
				{
					[confirmRenameMailboxButton setEnabled: FALSE];
					[renameMailboxStatusField setStringValue:@"Mailbox already exists."];
				} 
				else 
				{
					[renameMailboxStatusField setStringValue:@""];
					[confirmRenameMailboxButton setEnabled: TRUE];
				}
			}
		} 
		else 
		{
			[confirmRenameMailboxButton setEnabled: FALSE];
		}
	} 
	else if ([aNotification object] == newAclUsernameTextField) 
	{
		if ( [[[aNotification object] stringValue]isEqualToString:@""])
			[confirmCreateACLButton setEnabled:FALSE];
		else
			[confirmCreateACLButton setEnabled:TRUE];
	} 
}

- (void)controlTextDidEndEditing:(NSNotification *)aNotification 
{
	if ( ([aNotification object] == addressTextField) || ([aNotification object] == usernameTextField) || ([aNotification object] == passwordTextField) ) 
	{
		if ([[addressTextField stringValue] isEqualToString:@""] || [[usernameTextField stringValue] isEqualToString:@""] || [[passwordTextField stringValue] isEqualToString:@""] ) 
			[connectButton setEnabled:FALSE];
		else
			[connectButton setEnabled:TRUE];
	}

	if ([aNotification object] == newMailboxTextField) 
	{
		if (! [[[[aNotification object] stringValue] substringFromIndex:([[[aNotification object] stringValue] length] -1)] isEqualToString:@"/"]) 
		{
			if ( [[aNotification object] stringValue] != NULL) 
			{
				if ( [_mailboxesArray containsObject:[NSDictionary dictionaryWithObject:[[aNotification object] stringValue] forKey:@"name"]]) 
				{
					[confirmCreateMailboxButton setEnabled: FALSE];
					[newMailboxStatusField setStringValue:@"Mailbox already exists."];
				} 
				else 
				{
					[newMailboxStatusField setStringValue:@""];
					[confirmCreateMailboxButton setEnabled: TRUE];
				}
			}
		} 
		else 
		{
			[confirmCreateMailboxButton setEnabled: FALSE];
		}	
	} 
	else if ([aNotification object] == newNameMailboxTextField) 
	{
		if (! [[[[aNotification object] stringValue] substringFromIndex:([[[aNotification object] stringValue] length] -1)] isEqualToString:@"/"]) 
		{
			if ( [[aNotification object] stringValue] != NULL) 
			{
				if ( [_mailboxesArray containsObject:[NSDictionary dictionaryWithObject:[[aNotification object] stringValue] forKey:@"name"]]) 
				{
					[confirmRenameMailboxButton setEnabled: FALSE];
					[renameMailboxStatusField setStringValue:@"Mailbox already exists."];
				} 
				else 
				{
					[renameMailboxStatusField setStringValue:@""];
					[confirmRenameMailboxButton setEnabled: TRUE];
				}
			}
		} 
		else 
		{
			[confirmRenameMailboxButton setEnabled: FALSE];
		}
	} 
	else if ([aNotification object] == newAclUsernameTextField) 
	{
		if ( [[[aNotification object] stringValue]isEqualToString:@""]) 
			[confirmCreateACLButton setEnabled:FALSE];
		else
			[confirmCreateACLButton setEnabled:TRUE];
	}
	else if ( ([aNotification object] == updateMailboxCommentTextField) || ([aNotification object] == updateMailboxExpireTextField) )
	{
		if ( (![[updateMailboxCommentTextField stringValue] isEqualToString:[self mailboxComment]]) || (![[updateMailboxExpireTextField stringValue] isEqualToString:[self mailboxExpire]]) )
			[confirmUpdateMailboxMetadataButton setEnabled:TRUE];
		else
			[confirmUpdateMailboxMetadataButton setEnabled:FALSE];
	}	
}


- (BOOL)selectionShouldChangeInTableView:(NSTableView *)aTableView 
{
	if (aTableView == mailboxesTable) 
	{
		return commandFinished;
	} 
	else if (aTableView == aclsTable) 
	{
		if ( [[mailboxesController selectedObjects] count] > 1 )
			return FALSE;
		else
			return TRUE;
	}
	return TRUE;
}


- (BOOL)tableView:(NSTableView *)aTableView shouldSelectTableColumn:(NSTableColumn *)aTableColumn 
{
	if (aTableView == aclsTable) 
		return FALSE;
	else
		return TRUE;
}


- (void)tableViewSelectionDidChange:(NSNotification *)aNotification 
{
	if ( [aNotification object] == mailboxesTable ) 
	{
		if ( [[mailboxesController selectedObjects] count] > 1 ) 
		{
			// more than one selected, so just leave some things enabled?
			[aclsController setSelectionIndex:0];
			NSMutableDictionary* tempDict = [NSMutableDictionary dictionaryWithObjects: [NSArray arrayWithObjects:@"         Multiple", @"",@"",@"",@"",@"",@"",@"",@"",@"", nil]
										forKeys:[NSArray arrayWithObjects:@"User",@"l",@"r",@"s",@"w",@"i",@"p",@"c",@"d",@"a", nil]];
			NSMutableDictionary* tempDict2 = [NSMutableDictionary dictionaryWithObjects: [NSArray arrayWithObjects:@"mailboxes selected.", @"",@"",@"",@"",@"",@"",@"",@"",@"", nil]
										forKeys:[NSArray arrayWithObjects:@"User",@"l",@"r",@"s",@"w",@"i",@"p",@"c",@"d",@"a", nil]];	
			NSMutableDictionary* tempDict3 = [NSMutableDictionary dictionaryWithObjects: [NSArray arrayWithObjects:@"  Certain functions", @"",@"",@"",@"",@"",@"",@"",@"",@"", nil]
										forKeys:[NSArray arrayWithObjects:@"User",@"l",@"r",@"s",@"w",@"i",@"p",@"c",@"d",@"a", nil]];
			NSMutableDictionary* tempDict4 = [NSMutableDictionary dictionaryWithObjects: [NSArray arrayWithObjects:@"    are unavailable.", @"",@"",@"",@"",@"",@"",@"",@"",@"", nil]
										forKeys:[NSArray arrayWithObjects:@"User",@"l",@"r",@"s",@"w",@"i",@"p",@"c",@"d",@"a", nil]];																												
			[self setAcls:[NSArray arrayWithObjects:tempDict, tempDict2, tempDict3, tempDict4, nil]];
			[aclsController setEditable:FALSE];
			[aclsController setSelectedObjects:nil];
			[renameMailboxButton setEnabled:FALSE];
			[self setQuotaRoot:@""];
			[self setQuotaUsed:@""];
			[self setQuotaQuota:@""];
			[self setMailboxComment:@""];
			[self setMailboxLastUpdated:@""];
			[self setMailboxPartition:@""];
			[self setMailboxSize:@""];
			[self setMailboxExpire:@""];
			[self setMailboxSquat:@""];
		} 
		else if ( [[mailboxesController selectedObjects] count] == 1) 
		{
			// just one selected, so do the standard thing.
			[self enableMailboxElements];
			[self retrieveAccessControls];
			if ([[[mailboxTabView selectedTabViewItem] label] isEqualToString:@"Metadata"])
				[self retrieveMailboxAnnotations];
			else if ([[[mailboxTabView selectedTabViewItem] label] isEqualToString:@"Quota"])
				[self retrieveQuotaInfo];
			
			if ( [aclsTable selectedRow] > -1 )
				[deleteAclButton setEnabled:TRUE];
			else
				[deleteAclButton setEnabled:FALSE];	
		} 
		else 
		{
			// must be an empty selection
			[self disableMailboxElements];
			[self setAcls:nil];
			[self setQuotaRoot:nil];
			[self setQuotaUsed:nil];
			[self setQuotaQuota:nil];
		}
	} 
	else if ( [aNotification object] == aclsTable ) 
	{
		if ( [aclsTable selectedRow] > -1 ) 
		{
			if ( [_aclsArray count] > 0 ) 
				[deleteAclButton setEnabled:TRUE];
			else
				[deleteAclButton setEnabled:FALSE];
		} 
		else 
		{
			[deleteAclButton setEnabled:FALSE];
		}
	}
}


- (NSString *)tableView:(NSTableView *)aTableView toolTipForCell:(NSCell *)aCell rect:(NSRectPointer)rect tableColumn:(NSTableColumn *)aTableColumn row:(int)row mouseLocation:(NSPoint)mouseLocation 
{
	if (aTableView == mailboxesTable) 
	{
		return @"mailbox name and path";
	} 
	else if (aTableView == aclsTable) 
	{
		if ( [[aTableColumn identifier]isEqualToString:@"user"] )
			return @"Username";
		else if ( [[aTableColumn identifier]isEqualToString:@"l"] )
			return @"Look up name of mailbox";
		else if ( [[aTableColumn identifier]isEqualToString:@"r"] )
			return @"Read the contents of mailbox"; 
		else if ( [[aTableColumn identifier]isEqualToString:@"s"] )
			return @"Preserve seen/recent status"; 
		else if ( [[aTableColumn identifier]isEqualToString:@"w"] )
			return @"Write message flags"; 		
		else if ( [[aTableColumn identifier]isEqualToString:@"i"] )
			return @"Move/Copy messages into mailbox"; 
		else if ( [[aTableColumn identifier]isEqualToString:@"p"] )
			return @"Post messages to mailbox"; 					
		else if ( [[aTableColumn identifier]isEqualToString:@"c"] )
			return @"Create a new child of this mailbox"; 
		else if ( [[aTableColumn identifier]isEqualToString:@"d"] )
			return @"Delete messages and/or this mailbox"; 
		else if ( [[aTableColumn identifier]isEqualToString:@"a"] )
			return @"Administer the ACLs of this mailbox"; 
		else
			return @"";
	} 
	else 
	{
		return @"";
	}
}


- (void)tabView:(NSTabView *)tabView willSelectTabViewItem:(NSTabViewItem *)tabViewItem
{
	if ([[tabViewItem label] isEqualToString:@"Metadata"])
		[self retrieveMailboxAnnotations];
	else if ([[tabViewItem label] isEqualToString:@"Quota"])
		[self retrieveQuotaInfo];
}


#pragma mark-
#pragma mark Key/Value Accessors

- (NSMutableArray *)mailboxes 
{
	return _mailboxesArray;
}


- (void)setMailboxes:(NSMutableArray *)newMailboxesArray 
{
    if (_mailboxesArray != newMailboxesArray)
	{
        [_mailboxesArray autorelease];
        _mailboxesArray = [newMailboxesArray mutableCopy];
    }
}


- (NSMutableArray *)acls 
{
	return _aclsArray;
}


- (void)setAcls:(NSMutableArray *)newAclsArray 
{
    if (_aclsArray != newAclsArray) 
	{
        [_aclsArray autorelease];
        _aclsArray = [newAclsArray mutableCopy];
    }
}


- (NSMutableString *)quotaRoot 
{
	return _quotaRoot;
}


- (void)setQuotaRoot:(NSMutableString*)newQuotaRoot 
{
    if (_quotaRoot != newQuotaRoot) 
	{
        [_quotaRoot autorelease];
        _quotaRoot = [newQuotaRoot mutableCopy];
    }
}


- (NSMutableString *)quotaUsed 
{
	return _quotaUsed;
}


- (void)setQuotaUsed:(NSMutableString*)newQuotaUsed 
{
    if (_quotaUsed != newQuotaUsed) 
	{
        [_quotaUsed autorelease];
        _quotaUsed = [newQuotaUsed mutableCopy];
    }
}


- (NSMutableString *)quotaQuota 
{
	return _quotaQuota;
}


- (void)setQuotaQuota:(NSMutableString*)newQuotaQuota 
{
    if (_quotaQuota != newQuotaQuota) 
	{
        [_quotaQuota autorelease];
        _quotaQuota = [newQuotaQuota mutableCopy];
    }
}


- (NSMutableArray *)usernames 
{
	return _usernames;
}


- (void)setUsernames:(NSMutableArray *)newUsernames 
{
    if (_usernames != newUsernames)
	{
        [_usernames autorelease];
        _usernames = [newUsernames mutableCopy];
    }
}


- (NSColor *)aclsTableTextColor 
{
	if ( [[mailboxesController selectedObjects] count] > 1 )
		return [NSColor disabledControlTextColor];
	else
		return [NSColor controlTextColor];
}


- (void)setAclsTableTextColor:(NSColor*)newTextColor 
{

}


- (BOOL)aclsTableEnabled 
{
	if ( [[mailboxesController selectedObjects] count] > 1 )
		return FALSE;
	else
		return FALSE;
}


- (void)setAclsTableEnabled:(BOOL)newAclsTableEnabled 
{

}


- (NSMutableString *)mailboxComment
{
	return _mailboxComment;
}


- (void)setMailboxComment:(NSMutableString *)newMailboxComment
{
    if (_mailboxComment != newMailboxComment) 
	{
        [_mailboxComment autorelease];
        _mailboxComment = [newMailboxComment mutableCopy];
    }
}


- (NSMutableString *)mailboxLastUpdated
{
	return _mailboxLastUpdated;
}


- (void)setMailboxLastUpdated:(NSMutableString *)newMailboxLastUpdated
{
    if (_mailboxLastUpdated != newMailboxLastUpdated) 
	{
        [_mailboxLastUpdated autorelease];
        _mailboxLastUpdated = [newMailboxLastUpdated mutableCopy];
    }
}


- (NSMutableString *)mailboxPartition
{
	return _mailboxPartition;
}


- (void)setMailboxPartition:(NSMutableString *)newMailboxPartition
{
    if (_mailboxPartition != newMailboxPartition) 
	{
        [_mailboxPartition autorelease];
        _mailboxPartition = [newMailboxPartition mutableCopy];
    }
}


- (NSMutableString *)mailboxSize
{
	return _mailboxSize;
}


- (void)setMailboxSize:(NSMutableString *)newMailboxSize
{
    if (_mailboxSize != newMailboxSize) 
	{
        [_mailboxSize autorelease];
        _mailboxSize = [newMailboxSize mutableCopy];
    }
}


- (NSMutableString *)mailboxExpire
{
	return _mailboxExpire;
}


- (void)setMailboxExpire:(NSMutableString *)newMailboxExpire
{
    if (_mailboxExpire != newMailboxExpire) 
	{
        [_mailboxExpire autorelease];
        _mailboxExpire = [newMailboxExpire mutableCopy];
    }
}


- (NSMutableString *)mailboxSquat
{
	return _mailboxSquat;
}


- (void)setMailboxSquat:(NSMutableString *)newMailboxSquat
{
    if (_mailboxSquat != newMailboxSquat) 
	{
        [_mailboxSquat autorelease];
        _mailboxSquat = [newMailboxSquat mutableCopy];
    }
}

@end
