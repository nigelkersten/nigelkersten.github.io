//
//  NKCramMD5.h
//  Test
//
//  Created by Nigel Kersten on 11/05/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <openssl/evp.h>
#import "NSString-Base64Extensions.h"
#import "NSData-Base64Extensions.h"

@interface NKCramMD5 : NSObject {

}
+ (NSString*)imapCramMd5ResultForUsername:(NSString*)aUsername password:(NSString*)aPassword challenge:(NSString*)aChallenge;

@end
