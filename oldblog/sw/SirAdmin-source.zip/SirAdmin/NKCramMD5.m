//
//  NKCramMD5.m
//  Test
//
//  Created by Nigel Kersten on 11/05/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "NKCramMD5.h"


@implementation NKCramMD5

+ (NSString*)imapCramMd5ResultForUsername:(NSString*)aUsername password:(NSString*)aPassword challenge:(NSString*)aChallenge {
	EVP_MD_CTX mdctx;  
	unsigned char md_value[EVP_MAX_MD_SIZE];
	unsigned int md_len, i;
  
/* pointer to data stream */
	NSString *decodedText = [[NSString alloc] initWithData:[aChallenge decodeBase64WithNewlines:NO] encoding:NSUTF8StringEncoding];
	const char* text = [decodedText cString];
	[decodedText release];
/* pointer to authentication key */
	const char* key = [aPassword cString];
	
	unsigned char k_ipad[65];     /* inner padding - key XORd with ipad */
	unsigned char k_opad[65];     /* outer padding - key XORd with opad */

/* start out by storing key in pads */
	bzero( k_ipad, sizeof k_ipad);
	bzero( k_opad, sizeof k_opad);
	bcopy( key, k_ipad, strlen(key));
	bcopy( key, k_opad, strlen(key));
  
/* XOR key with ipad and opad values */
	for (i=0; i<64; i++) {
		 k_ipad[i] ^= 0x36;
		 k_opad[i] ^= 0x5c;
	}
  
/*  perform inner MD5*/
  
	EVP_MD_CTX_init(&mdctx);                        /*init digest context*/
	EVP_DigestInit_ex(&mdctx, EVP_md5(), NULL);     /*set up digest context to use MD5*/
	EVP_DigestUpdate(&mdctx, k_ipad, 64);           /*hash ipad into digest context*/
	EVP_DigestUpdate(&mdctx, text, strlen(text));   /*hash the text into the digest context*/
	EVP_DigestFinal_ex(&mdctx, md_value, &md_len);  
	EVP_MD_CTX_cleanup(&mdctx);

/*  perform outer MD5*/

	EVP_MD_CTX_init(&mdctx);
	EVP_DigestInit_ex(&mdctx, EVP_md5(), NULL);
	EVP_DigestUpdate(&mdctx, k_opad, 64);
	EVP_DigestUpdate(&mdctx, md_value, 16);
	EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
	EVP_MD_CTX_cleanup(&mdctx);
  
	NSMutableString *digestString = [NSMutableString stringWithString:aUsername];
	[digestString appendString:@" "];
	
	for(i = 0; i < md_len; i++) {
		[digestString appendFormat:@"%02x", md_value[i]];
	}
	
	// now base64 encode it.
	return [[NSData dataWithBytes:[digestString cString] length:[digestString length]] encodeBase64WithNewlines:NO];
}

@end