/* AppController */

#import  <Cocoa/Cocoa.h>
#import  <CoreServices/CoreServices.h>
#import  <SystemConfiguration/SystemConfiguration.h>
#include <Security/SecKeychain.h>
#include <Security/SecKeychainItem.h>
#include <Security/SecAccess.h>
#include <Security/SecTrustedApplication.h>
#include <Security/SecACL.h>
#include <DirectoryService/DirServices.h>
#include <DirectoryService/DirServicesUtils.h>
#include <DirectoryService/DirServicesConst.h>
#include <math.h>

#import "AsyncSocket.h"
#import "AGKeychain.h"
#import "NSString-Base64Extensions.h"
#import "NSString-Base64Extensions.h"
#include "NKCramMD5.h"

@class AGKeychain;


@interface AppController : NSObject
{
	// login window
	IBOutlet NSWindow*				loginWindow;
    IBOutlet NSTextField*			addressTextField;
	IBOutlet NSTextField*			usernameTextField;
    IBOutlet NSSecureTextField*		passwordTextField;
	IBOutlet NSButton*				useSSLButton;
	IBOutlet NSButton*				rememberButton;
	IBOutlet NSProgressIndicator*	loginActivityIndicator;
	IBOutlet NSTextField*			loginStatusTextField;
    IBOutlet NSButton*				cancelButton;
    IBOutlet NSButton*				connectButton;
	
	// main window
    IBOutlet NSWindow*				mailboxesWindow;	
	IBOutlet NSButton*				refreshMailboxesButton;
	IBOutlet NSProgressIndicator*	activityIndicator;
	IBOutlet NSTextField*			activityTextField;
	IBOutlet NSTableView*			mailboxesTable;
	IBOutlet NSButton*				createMailboxButton;
	IBOutlet NSButton*				deleteMailboxButton;
	IBOutlet NSButton*				renameMailboxButton;
	IBOutlet NSButton*				reconstructMailboxButton;
	IBOutlet NSButton*				deleteAclButton;
	IBOutlet NSButton*				createAclButton;
	IBOutlet NSTableView*			aclsTable;
	IBOutlet NSTableColumn*			aclsTableUsernameColumn;
	IBOutlet NSTextField*			quotaRootTextField;
	IBOutlet NSTextField*			quotaUsedTextField;
	IBOutlet NSTextField*			quotaQuotaTextField;
	IBOutlet NSButton*				setQuotaButton;
	IBOutlet NSTabView*				mailboxTabView;
	
	// modal panels
	IBOutlet NSPanel*				createMailboxPanel;
	IBOutlet NSTextField*			newMailboxTextField;
	IBOutlet NSTextField*			newMailboxStatusField;
	IBOutlet NSButton*				confirmCreateMailboxButton;
	IBOutlet NSButton*				cancelCreateMailboxButton;
	
	IBOutlet NSPanel*				renameMailboxPanel;
	IBOutlet NSComboBox*			newNameMailboxTextField;
	IBOutlet NSTextField*			renameMailboxStatusField;
	IBOutlet NSButton*				confirmRenameMailboxButton;
	IBOutlet NSButton*				cancelRenameMailboxButton;
	
	IBOutlet NSPanel*				createACLPanel;
	IBOutlet NSButton*				confirmCreateACLButton;
	IBOutlet NSComboBox*			newAclUsernameTextField;
	IBOutlet NSButton*				aclCheckboxL;
	IBOutlet NSButton*				aclCheckboxR;
	IBOutlet NSButton*				aclCheckboxS;
	IBOutlet NSButton*				aclCheckboxW;
	IBOutlet NSButton*				aclCheckboxI;
	IBOutlet NSButton*				aclCheckboxP;
	IBOutlet NSButton*				aclCheckboxC;
	IBOutlet NSButton*				aclCheckboxD;	
	IBOutlet NSButton*				aclCheckboxA;
		
	IBOutlet NSPanel*				setQuotaPanel;
	IBOutlet NSTextField*			newQuotaTextField;
	IBOutlet NSButton*				confirmSetQuotaButton;
	
	IBOutlet NSPanel*				editMetadataPanel;
	IBOutlet NSButton*				confirmUpdateMailboxMetadataButton;
	IBOutlet NSTextField*			updateMailboxCommentTextField;
	IBOutlet NSTextField*			updateMailboxExpireTextField;
	IBOutlet NSButton*				updateMailboxSquatButton;
	IBOutlet NSTextField*			statusUpdateMetadataTextField;
	
	// preferences window
	IBOutlet NSWindow*				preferencesWindow;
	
	NSAutoreleasePool*				pool;
	AsyncSocket*					aSocket;
	NSMutableString*				writeString;
	NSError*						socketError;
	int								commandPrefix;
	BOOL							loggedIn;
	BOOL							commandFinished;
	
	IBOutlet NSArrayController*		mailboxesController;
	IBOutlet NSArrayController*		aclsController;
	NSMutableArray*					_mailboxesArray;
	NSMutableArray*					_aclsArray;
	NSMutableDictionary*			_usernamesDict;
	NSMutableArray*					_usernames;
	NSMutableString*				_quotaRoot;
	NSMutableString*				_quotaUsed;
	NSMutableString*				_quotaQuota;
	NSColor*						_aclsTableTextColor;
	NSMutableString*				_mailboxComment;
	NSMutableString*				_mailboxLastUpdated;
	NSMutableString*				_mailboxPartition;
	NSMutableString*				_mailboxSize;
	NSMutableString*				_mailboxExpire;
	NSMutableString*				_mailboxSquat;
	NSMutableString*				serverNamespace;
	NSMutableString*				serverPathSeparator;
	NSMutableString*				serverOtherUsersSeparator;
}

- (IBAction)cancel:(id)sender;
- (IBAction)connect:(id)sender;
- (IBAction)editPreferences:(id)sender;
- (IBAction)refreshMailboxes:(id)sender;

- (IBAction)disconnectFromServer:(id)sender;

- (IBAction)createMailbox:(id)sender;
- (IBAction)deleteMailbox:(id)sender;
- (IBAction)renameMailbox:(id)sender;
- (IBAction)reconstructMailbox:(id)sender;
- (IBAction)createAcl:(id)sender;
- (IBAction)deleteAcl:(id)sender;
- (IBAction)checkAclCheckboxes:(id)sender;
- (IBAction)checkSquatCheckbox:(id)sender;
- (IBAction)editMailboxMetadata:(id)sender;
- (IBAction)setQuota:(id)sender;

- (IBAction)confirmAlertPanel:(id)sender;
- (IBAction)abortAlertPanel:(id)sender;

- (IBAction)enableAllAclsForNewAcl:(id)sender;
- (void)connectionDisconnected:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo;

- (void)storePasswordInKeychainForUser:(NSString*)kUsername atHost:(NSString*)kHostname;

- (void)disableLoginElements;
- (void)enableLoginElements;
- (void)disableMailboxElements;
- (void)enableMailboxElements;

- (void)readFromServer;
- (void)retrieveAccessControls;
- (void)retrieveQuotaInfo;
- (void)retrieveMailboxAnnotations;
- (void)collectUsernamesFromDirectoryServices;

// bindings.

- (NSMutableArray *)mailboxes;
- (void)setMailboxes:(NSMutableArray *)newMailboxesArray;
- (NSMutableArray *)acls;
- (void)setAcls:(NSMutableArray *)newAclsArray;
- (NSMutableString *)quotaRoot;
- (void)setQuotaRoot:(NSMutableString*)newQuotaRoot;
- (NSMutableString *)quotaUsed;
- (void)setQuotaUsed:(NSMutableString*)newQuotaUsed;
- (NSMutableString *)quotaQuota;
- (void)setQuotaQuota:(NSMutableString*)newQuotaQuota;
- (NSMutableArray *)usernames;
- (void)setUsernames:(NSMutableArray *)newUsernames;
- (NSColor *)aclsTableTextColor;
- (void)setAclsTableTextColor:(NSColor*)newTextColor;
- (BOOL)aclsTableEnabled;
- (void)setAclsTableEnabled:(BOOL)newAclsTableEnabled;
- (NSMutableString *)mailboxComment;
- (void)setMailboxComment:(NSMutableString *)newMailboxComment;
- (NSMutableString *)mailboxLastUpdated;
- (void)setMailboxLastUpdated:(NSMutableString *)newMailboxLastUpdated;
- (NSMutableString *)mailboxPartition;
- (void)setMailboxPartition:(NSMutableString *)newMailboxPartition;
- (NSMutableString *)mailboxSize;
- (void)setMailboxSize:(NSMutableString *)newMailboxSize;
- (NSMutableString *)mailboxExpire;
- (void)setMailboxExpire:(NSMutableString *)newMailboxExpire;
- (NSMutableString *)mailboxSquat;
- (void)setMailboxSquat:(NSMutableString *)newMailboxSquat;

-(void)doWriteCramMd5Login;
-(void)doWriteCramMd5Response:(NSString*)incomingString;
-(void)doWritePlainTextLogin;
-(void)doWriteNamespaceRequest;
-(void)didReadCapabilities:(NSString*)incomingString;
-(void)didReadMailboxList:(NSString*)incomingString;
-(void)didReadAclList:(NSString*)incomingString;
-(void)didReadQuotaRoot:(NSString*)incomingString;
-(void)didReadQuotaQuota:(NSString*)incomingString;
-(void)didReadAnnotation:(NSString*)incomingString;
-(void)didReadLogin:(NSString*)incomingString;
-(void)didReadNamespaceRequest:(NSString*)incomingString;


@end
